package com.example.photomerge

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.exifinterface.media.ExifInterface
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.Calendar

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

class Folder(val uri: Uri, val name: String, val photos: Int, val videos: Int, val thumbs: List<Uri>) { var selected by mutableStateOf(true) }
class Item(val doc: DocumentFile, val parent: Uri, val video: Boolean)
class Seen(val uri: Uri) { var h: String? = null }
class Opts(val deep: Boolean, val byDate: Boolean, val skip: Boolean, val copy: Boolean, val clean: Boolean, val videos: Boolean)
class Stats { var moved = 0; var skipped = 0; var renamed = 0; var failed = 0; var bytes = 0L }
class Undo(val doc: Uri, val from: Uri, val to: Uri, val copy: Boolean)

fun id(u: Uri): String = DocumentsContract.getDocumentId(u)

fun collect(dir: DocumentFile, deep: Boolean, vid: Boolean, skipId: String?, out: MutableList<Item>) {
    for (f in dir.listFiles()) {
        if (f.isDirectory) {
            if (deep && id(f.uri) != skipId) collect(f, true, vid, skipId, out)
        } else {
            val t = f.type ?: ""
            if (t.startsWith("image/") || (vid && t.startsWith("video/"))) out.add(Item(f, dir.uri, t.startsWith("video/")))
        }
    }
}

fun scan(ctx: Context, uri: Uri, deep: Boolean, vid: Boolean): Folder {
    val root = DocumentFile.fromTreeUri(ctx, uri)!!
    val items = ArrayList<Item>()
    collect(root, deep, vid, null, items)
    return Folder(uri, root.name ?: "Folder", items.count { !it.video }, items.count { it.video },
        items.filter { !it.video }.take(4).map { it.doc.uri })
}

fun sub(root: DocumentFile, path: String, create: Boolean, cache: HashMap<String, DocumentFile>): DocumentFile? {
    if (path.isEmpty()) return root
    cache[path]?.let { return it }
    var cur: DocumentFile = root
    for (part in path.split("/")) {
        val next = cur.findFile(part)?.takeIf { it.isDirectory } ?: (if (create) cur.createDirectory(part) else null)
        cur = next ?: return null
    }
    cache[path] = cur
    return cur
}

fun unique(name: String, used: Map<String, Long>): String {
    val dot = name.lastIndexOf('.')
    val base = if (dot > 0) name.substring(0, dot) else name
    val ext = if (dot > 0) name.substring(dot) else ""
    var n = 1
    while (used.containsKey("$base ($n)$ext".lowercase())) n++
    return "$base ($n)$ext"
}

fun hash(ctx: Context, u: Uri): String = try {
    val md = MessageDigest.getInstance("SHA-256")
    ctx.contentResolver.openInputStream(u)?.use { i ->
        val b = ByteArray(65536)
        while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) }
    }
    md.digest().joinToString("") { "%02x".format(it) }
} catch (e: Exception) { u.toString() }

fun dateParts(ctx: Context, item: Item): String {
    var y = 0
    var m = 0
    try {
        if (item.video) {
            val r = MediaMetadataRetriever()
            r.setDataSource(ctx, item.doc.uri)
            val s = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DATE)
            r.release()
            if (s != null && s.length >= 6) { y = s.substring(0, 4).toInt(); m = s.substring(4, 6).toInt() }
        } else {
            ctx.contentResolver.openInputStream(item.doc.uri)?.use { i ->
                val s = ExifInterface(i).getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)
                if (s != null && s.length >= 7) { y = s.substring(0, 4).toInt(); m = s.substring(5, 7).toInt() }
            }
        }
    } catch (e: Exception) { }
    if (y < 1990 || m !in 1..12) {
        val t = item.doc.lastModified()
        if (t == 0L) return "Unknown date"
        val c = Calendar.getInstance().apply { timeInMillis = t }
        y = c.get(Calendar.YEAR); m = c.get(Calendar.MONTH) + 1
    }
    return String.format("%d/%02d", y, m)
}

fun saveUndo(ctx: Context, l: List<Undo>) {
    try { File(ctx.filesDir, "undo.log").writeText(l.joinToString("\n") { u -> "${u.copy}\t${u.doc}\t${u.from}\t${u.to}" }) } catch (e: Exception) { }
}

fun loadUndo(ctx: Context): List<Undo> = try {
    File(ctx.filesDir, "undo.log").readLines().filter { it.isNotBlank() }.map { line ->
        val p = line.split("\t")
        Undo(Uri.parse(p[1]), Uri.parse(p[2]), Uri.parse(p[3]), p[0] == "true")
    }
} catch (e: Exception) { emptyList() }

fun transfer(ctx: Context, item: Item, dir: DocumentFile?, name: String, copy: Boolean, log: MutableList<Undo>): Uri? {
    if (dir == null) return null
    val d = item.doc
    try {
        if (!copy && name == d.name) {
            val m = try { DocumentsContract.moveDocument(ctx.contentResolver, d.uri, item.parent, dir.uri) } catch (e: Exception) { null }
            if (m != null) { log.add(Undo(m, item.parent, dir.uri, false)); return m }
        }
        val out = dir.createFile(d.type ?: "image/jpeg", name) ?: return null
        val n = ctx.contentResolver.openInputStream(d.uri)?.use { i ->
            ctx.contentResolver.openOutputStream(out.uri)?.use { o -> i.copyTo(o) }
        } ?: -1L
        if (n != d.length()) { out.delete(); return null }
        if (copy) log.add(Undo(out.uri, item.parent, dir.uri, true)) else d.delete()
        return out.uri
    } catch (e: Exception) { return null }
}

fun prune(d: DocumentFile, keepId: String): Boolean {
    var empty = true
    for (k in d.listFiles()) {
        if (k.isDirectory && id(k.uri) != keepId && prune(k, keepId)) continue
        empty = false
    }
    val gone = empty && id(d.uri) != keepId
    if (gone) d.delete()
    return gone
}

fun merge(ctx: Context, srcs: List<Uri>, destUri: Uri, o: Opts, dry: Boolean, log: MutableList<Undo>, onProg: (Float) -> Unit): Stats {
    val r = Stats()
    val dest = DocumentFile.fromTreeUri(ctx, destUri) ?: return r
    val destId = id(dest.uri)
    val roots = srcs.mapNotNull { DocumentFile.fromTreeUri(ctx, it) }
    val items = ArrayList<Item>()
    roots.forEach { collect(it, o.deep, o.videos, destId, items) }
    val cache = HashMap<String, DocumentFile>()
    val taken = HashMap<String, HashMap<String, Long>>()
    val seen = HashMap<Long, MutableList<Seen>>()
    if (o.skip) {
        val ex = ArrayList<Item>()
        collect(dest, true, true, null, ex)
        ex.forEach { e -> seen.getOrPut(e.doc.length()) { ArrayList() }.add(Seen(e.doc.uri)) }
    }
    items.forEachIndexed { i, item ->
        val d = item.doc
        val name = d.name
        if (name != null) {
            val size = d.length()
            val same = seen.getOrPut(size) { ArrayList() }
            val h = if (o.skip && same.isNotEmpty()) hash(ctx, d.uri) else null
            val dup = h != null && same.any { s -> (s.h ?: hash(ctx, s.uri).also { x -> s.h = x }) == h }
            if (dup) {
                r.skipped++
            } else {
                val path = if (o.byDate) dateParts(ctx, item) else ""
                val names = taken.getOrPut(path) {
                    val m = HashMap<String, Long>()
                    sub(dest, path, false, cache)?.listFiles()?.forEach { f -> f.name?.let { n -> m[n.lowercase()] = f.length() } }
                    m
                }
                val newName = if (names.containsKey(name.lowercase())) unique(name, names) else name
                val res: Uri? = if (dry) d.uri else transfer(ctx, item, sub(dest, path, true, cache), newName, o.copy, log)
                if (res != null) {
                    r.moved++; r.bytes += size
                    if (newName != name) r.renamed++
                    names[newName.lowercase()] = size
                    same.add(Seen(res).also { s -> s.h = h })
                } else r.failed++
            }
        }
        onProg((i + 1f) / items.size)
    }
    if (!dry && o.clean && !o.copy) roots.forEach { prune(it, destId) }
    return r
}

@Composable
fun FolderCard(f: Folder, onRemove: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(f.selected, { f.selected = it })
                Column(Modifier.weight(1f)) {
                    Text(f.name, style = MaterialTheme.typography.titleMedium)
                    Text("${f.photos} photos · ${f.videos} videos")
                }
                TextButton(onClick = onRemove) { Text("✕") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                f.thumbs.forEach {
                    AsyncImage(it, null, Modifier.size(72.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
                }
            }
        }
    }
}

@Composable
fun Opt(label: String, v: Boolean, set: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(v, set)
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val folders = remember { mutableStateListOf<Folder>() }
    val undo = remember { mutableStateListOf<Undo>().also { it.addAll(loadUndo(ctx)) } }
    var dest by remember { mutableStateOf<Uri?>(null) }
    var destName by remember { mutableStateOf("") }
    var deep by remember { mutableStateOf(true) }
    var byDate by remember { mutableStateOf(false) }
    var skip by remember { mutableStateOf(true) }
    var copy by remember { mutableStateOf(false) }
    var clean by remember { mutableStateOf(false) }
    var videos by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var prog by remember { mutableStateOf(0f) }
    var msg by remember { mutableStateOf("") }
    val rw = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION

    val pickSrc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null && folders.none { it.uri == uri }) {
            ctx.contentResolver.takePersistableUriPermission(uri, rw)
            scope.launch { folders.add(withContext(Dispatchers.IO) { scan(ctx, uri, deep, videos) }) }
        }
    }
    val pickDst = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(uri, rw)
            dest = uri
            destName = DocumentFile.fromTreeUri(ctx, uri)?.name ?: "Folder"
        }
    }

    fun go(dry: Boolean) {
        val d = dest ?: return
        scope.launch {
            busy = true; msg = ""; prog = 0f
            val log = ArrayList<Undo>()
            val srcs = folders.filter { it.selected }.map { it.uri }
            val o = Opts(deep, byDate, skip, copy, clean, videos)
            val r = withContext(Dispatchers.IO) { merge(ctx, srcs, d, o, dry, log) { prog = it } }
            val verb = if (copy) "copy" else "move"
            if (dry) {
                msg = "Preview: would $verb ${r.moved} files (${r.bytes / 1048576} MB), skip ${r.skipped} duplicates, rename ${r.renamed}. Nothing was changed."
            } else {
                if (clean || log.isNotEmpty()) { undo.clear(); if (!clean) undo.addAll(log); saveUndo(ctx, undo.toList()) }
                folders.clear()
                msg = "Done: ${r.moved} files, ${r.skipped} duplicates skipped, ${r.renamed} renamed, ${r.failed} failed."
            }
            busy = false
        }
    }

    fun undoAll() {
        scope.launch {
            busy = true
            val n = withContext(Dispatchers.IO) {
                var c = 0
                for (u in undo.reversed()) {
                    try {
                        if (u.copy) { if (DocumentFile.fromSingleUri(ctx, u.doc)?.delete() == true) c++ }
                        else if (DocumentsContract.moveDocument(ctx.contentResolver, u.doc, u.to, u.from) != null) c++
                    } catch (e: Exception) { }
                }
                c
            }
            undo.clear(); saveUndo(ctx, emptyList()); msg = "Undone: $n files put back."; busy = false
        }
    }

    val ready = !busy && dest != null && folders.any { it.selected }
    LazyColumn(Modifier.fillMaxSize().systemBarsPadding(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Photo Merge", style = MaterialTheme.typography.headlineLarge)
            Text("Combine picture folders on your SD card")
        }
        item { Text("1 · Folders to merge", style = MaterialTheme.typography.titleLarge) }
        items(folders) { f -> FolderCard(f) { folders.remove(f) } }
        item { Button(onClick = { pickSrc.launch(null) }, enabled = !busy) { Text("+ Add folder") } }
        item { Text("2 · Where should they go?", style = MaterialTheme.typography.titleLarge) }
        item { OutlinedButton(onClick = { pickDst.launch(null) }, enabled = !busy) { Text(if (dest == null) "Pick destination folder" else "📁 $destName") } }
        item {
            Text("3 · Options", style = MaterialTheme.typography.titleLarge)
            Opt("Include subfolders", deep) { deep = it }
            Opt("Include videos", videos) { videos = it }
            Opt("Sort into Year / Month folders (date taken)", byDate) { byDate = it }
            Opt("Skip duplicates (same content)", skip) { skip = it }
            Opt("Copy instead of move (keeps originals)", copy) { copy = it }
            Opt("Remove emptied folders (no undo)", clean) { clean = it }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = { go(true) }, enabled = ready) { Text("Preview") }
                Button(onClick = { go(false) }, enabled = ready) { Text("Merge now") }
            }
        }
        item {
            if (busy) LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth())
            if (msg.isNotEmpty()) Card(Modifier.fillMaxWidth()) { Text(msg, Modifier.padding(12.dp)) }
            if (undo.isNotEmpty() && !busy) OutlinedButton(onClick = { undoAll() }) { Text("↩ Undo last merge") }
        }
    }
}
